// src/hooks/useChat.js
import { useState, useCallback } from 'react';

export const useChat = () => {
  const [chatHistory, setChatHistory] = useState([
    {
      id: 1,
      type: 'system',
      content: 'Welcome to FarmAssist AI! 🌱\n\nI\'m here to help you with:\n• Crop disease identification\n• Soil health analysis\n• Weather and irrigation advice\n• Pest management strategies\n• Fertilizer recommendations\n• Harvest timing guidance\n\nYou can ask questions through text, voice, or by uploading images of your crops or fields.',
      timestamp: new Date().toISOString(),
    }
  ]);
  
  const [isTyping, setIsTyping] = useState(false);

  const sendMessage = useCallback(async (messageText, image) => {
    if (!messageText.trim() && !image) return;

    // Add user message
    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: messageText,
      image: image,
      timestamp: new Date().toISOString(),
    };

    setChatHistory(prev => [...prev, userMessage]);

    // Show typing indicator
    setIsTyping(true);

    // Simulate API call delay
    setTimeout(() => {
      // Add AI response
      const aiResponse = {
        id: Date.now() + 1,
        type: 'assistant',
        content: generateAIResponse(messageText, image),
        context: getRandomContext(),
        confidence: `${Math.floor(Math.random() * 20) + 80}%`,
        timestamp: new Date().toISOString(),
      };

      setChatHistory(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 2000 + Math.random() * 1000); // Random delay between 2-3 seconds
  }, []);

  const handleFeedback = useCallback((messageId, feedbackType) => {
    console.log(`Feedback for message ${messageId}: ${feedbackType}`);
    // Here you would typically send feedback to your backend
    
    // Show a toast notification (you can implement this)
    const feedbackMessage = feedbackType === 'helpful' 
      ? 'Thanks for your feedback! This helps us improve.' 
      : 'Thanks for letting us know. We\'ll work on improving our responses.';
    
    // You could show this as a temporary message or toast
    alert(feedbackMessage);
  }, []);

  const handleEscalate = useCallback((messageId) => {
    console.log(`Escalating message ${messageId} to expert`);
    // Here you would typically connect to an expert or support system
    
    // Add system message about escalation
    const escalationMessage = {
      id: Date.now(),
      type: 'system',
      content: 'Connecting you to an agricultural expert... Please hold while we find the best specialist for your query. An expert will join this conversation shortly.',
      timestamp: new Date().toISOString(),
    };
    
    setChatHistory(prev => [...prev, escalationMessage]);
    
    // Simulate expert connection
    setTimeout(() => {
      const expertMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: 'Hello! I\'m Dr. Sarah Johnson, an agricultural specialist. I see you need expert assistance. I\'m here to provide detailed guidance for your farming concerns. Please share more details about your specific situation.',
        context: 'Expert Consultation',
        timestamp: new Date().toISOString(),
      };
      setChatHistory(prev => [...prev, expertMessage]);
    }, 3000);
  }, []);

  return {
    chatHistory,
    isTyping,
    sendMessage,
    handleFeedback,
    handleEscalate
  };
};

// Helper functions
const generateAIResponse = (userMessage, image) => {
  if (image) {
    const imageResponses = [
      "I can analyze your uploaded image. Based on what I observe, this appears to show signs that require attention. Let me provide specific recommendations for addressing this agricultural concern.",
      "Thank you for uploading the image. I can see specific visual indicators that help me provide targeted advice for your crops. Here are my observations and recommendations.",
      "Based on your image analysis, I can identify several key factors that affect plant health. The visual symptoms suggest specific conditions that can be managed effectively.",
      "Excellent photo! This visual information allows me to give you precise guidance. I can see the condition you're concerned about and recommend appropriate treatment strategies."
    ];
    return imageResponses[Math.floor(Math.random() * imageResponses.length)];
  }

  // Generate contextual responses based on keywords
  const lowerMessage = userMessage.toLowerCase();
  
  if (lowerMessage.includes('disease') || lowerMessage.includes('pest') || lowerMessage.includes('problem')) {
    const diseaseResponses = [
      "Disease management is crucial for healthy crops. Based on your description, I recommend implementing integrated pest management (IPM) strategies. This includes regular monitoring, proper sanitation, and using resistant varieties when available.",
      "Pest and disease control requires a systematic approach. First, identify the specific pathogen or pest, then choose appropriate biological or chemical controls. Prevention through good cultural practices is always the best strategy.",
      "For effective disease management, consider factors like crop rotation, proper spacing for air circulation, and timely application of fungicides if needed. Early detection is key to successful treatment."
    ];
    return diseaseResponses[Math.floor(Math.random() * diseaseResponses.length)];
  }
  
  if (lowerMessage.includes('soil') || lowerMessage.includes('fertilizer') || lowerMessage.includes('nutrient')) {
    const soilResponses = [
      "Soil health is the foundation of successful farming. I recommend conducting a comprehensive soil test to determine pH, nutrient levels, and organic matter content. This will guide your fertilization strategy.",
      "Nutrient management should be based on soil testing and crop requirements. Consider using a combination of organic amendments and targeted fertilizers to maintain soil fertility and structure.",
      "Healthy soil requires balanced nutrition and good structure. Focus on improving organic matter content, maintaining proper pH levels, and ensuring adequate drainage for optimal root development."
    ];
    return soilResponses[Math.floor(Math.random() * soilResponses.length)];
  }
  
  if (lowerMessage.includes('water') || lowerMessage.includes('irrigation') || lowerMessage.includes('drought')) {
    const waterResponses = [
      "Water management is critical for crop success. Consider implementing efficient irrigation systems like drip or sprinkler irrigation to optimize water use. Monitor soil moisture regularly to avoid over or under-watering.",
      "Proper irrigation timing and frequency depend on crop type, growth stage, and weather conditions. I recommend using soil moisture sensors and weather data to make informed irrigation decisions.",
      "Water conservation strategies include mulching, selecting drought-resistant varieties, and improving soil water-holding capacity through organic matter additions. Efficient scheduling prevents water waste."
    ];
    return waterResponses[Math.floor(Math.random() * waterResponses.length)];
  }
  
  if (lowerMessage.includes('weather') || lowerMessage.includes('climate') || lowerMessage.includes('temperature')) {
    const weatherResponses = [
      "Weather monitoring is essential for agricultural planning. I recommend using local weather forecasts and historical data to make decisions about planting, harvesting, and pest management activities.",
      "Climate considerations should guide your crop selection and management practices. Adapt to local conditions by choosing appropriate varieties and adjusting planting dates based on seasonal patterns.",
      "Weather-related stress can be managed through proper planning. Use protective measures like row covers, windbreaks, and shade structures when necessary to protect crops from extreme conditions."
    ];
    return weatherResponses[Math.floor(Math.random() * weatherResponses.length)];
  }
  
  // Default responses for general queries
  const generalResponses = [
    "Based on your farming query, I can provide specific recommendations tailored to your needs. Consider factors like local climate, soil conditions, and market demands when making agricultural decisions.",
    "Excellent question! Successful farming requires attention to multiple factors including soil health, water management, pest control, and timing. Let me provide detailed guidance for your specific situation.",
    "I understand your farming concern. Here's my analysis based on current agricultural best practices and research. This approach has shown positive results in similar farming conditions.",
    "Great topic for discussion! Evidence-based farming practices can significantly improve your results. I'll provide recommendations that consider both traditional knowledge and modern agricultural science.",
    "Your farming question touches on important agricultural principles. Let me share proven strategies that can help optimize your crop production and farm management efficiency."
  ];
  
  return generalResponses[Math.floor(Math.random() * generalResponses.length)];
};

const getRandomContext = () => {
  const contexts = [
    "Crop Management",
    "Disease Prevention", 
    "Soil Health",
    "Pest Control",
    "Weather Advisory",
    "Irrigation Management",
    "Fertilizer Guidance",
    "Harvest Planning",
    "Seed Selection",
    "Market Advisory",
    "Organic Farming",
    "Sustainable Agriculture"
  ];
  return contexts[Math.floor(Math.random() * contexts.length)];
};
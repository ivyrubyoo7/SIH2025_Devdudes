import React, { useState } from 'react';
import HomePage from './components/HomePage';
import ChatInterface from './components/ChatInterface';

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const navigateToChat = () => setCurrentPage('chat');
  const navigateToHome = () => setCurrentPage('home');

  return (
    <>
      {currentPage === 'home' && <HomePage onNavigateToChat={navigateToChat} />}
      {currentPage === 'chat' && <ChatInterface onNavigateHome={navigateToHome} />}
    </>
  );
};

export default App;
import React, { useRef, useState, useEffect } from 'react';
import { 
  Mic, 
  MicOff, 
  Send,
  X,
  ImageIcon,
  Paperclip
} from 'lucide-react';

const ChatInput = ({ 
  message, 
  setMessage, 
  isRecording, 
  setIsRecording,
  uploadedImage,
  setUploadedImage,
  uploadedFile,       // 👈 NEW PROP
  setUploadedFile,    // 👈 NEW PROP
  onSendMessage,
  isTyping = false
}) => {
  const fileInputRef = useRef(null);
  const docInputRef = useRef(null); // 👈 NEW REF
  const textareaRef = useRef(null);
  const recognitionRef = useRef(null);
  const [isFocused, setIsFocused] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';
      
      recognitionRef.current.onstart = () => {
        console.log('Speech recognition started');
      };
      
      recognitionRef.current.onresult = (event) => {
        let finalTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript;
          }
        }
        if (finalTranscript) {
          setMessage(prev => prev + finalTranscript);
        }
      };
      
      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
        switch (event.error) {
          case 'not-allowed':
            alert('Microphone access denied. Please allow microphone permission and try again.');
            break;
          case 'no-speech':
            alert('No speech detected. Please try again.');
            break;
          default:
            alert(`Speech recognition error: ${event.error}`);
        }
      };
      
      recognitionRef.current.onend = () => {
        console.log('Speech recognition ended');
        setIsRecording(false);
      };
      
      setSpeechSupported(true);
    } else {
      console.warn('Speech recognition not supported');
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [setMessage, setIsRecording]);

  const handleVoiceToggle = async () => {
    if (!speechSupported) {
      alert('Speech recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    if (!isRecording) {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true });
        recognitionRef.current?.start();
        setIsRecording(true);
      } catch (error) {
        console.error('Microphone permission error:', error);
        alert('Please allow microphone access to use voice input.');
      }
    } else {
      recognitionRef.current?.stop();
      setIsRecording(false);
    }
  };

  const handleImageUpload = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage();
    }
  };

  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
    }
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [message]);

  return (
    <div className="bg-white border-t border-gray-200 shadow-2xl">
      <div className="max-w-6xl mx-auto px-6 py-6">
        
        {/* Image Preview */}
        {uploadedImage && (
          <div className="mb-4">
            <div className="relative inline-block group">
              <div className="relative overflow-hidden rounded-xl border-2 border-emerald-200 shadow-lg">
                <img 
                  src={uploadedImage} 
                  alt="Preview" 
                  className="w-32 h-32 object-cover" 
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-200"></div>
              </div>
              <button 
                onClick={() => setUploadedImage(null)}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-110"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* File Preview */}
        {uploadedFile && (
          <div className="mb-4">
            <div className="relative inline-block group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl border-2 border-blue-200 shadow-lg bg-white">
                <Paperclip className="h-5 w-5 text-blue-500" />
                <span className="text-sm text-gray-700">{uploadedFile.name}</span>
              </div>
              <button 
                onClick={() => setUploadedFile(null)}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-110"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}
        
        {/* Input Container */}
        <div className={`relative bg-gray-50 rounded-2xl border-2 transition-all duration-300 ${
          isFocused 
            ? 'border-emerald-500 shadow-lg shadow-emerald-500/10 bg-white' 
            : 'border-gray-200 hover:border-gray-300'
        }`}>
          
          {/* Main Input Area */}
          <div className="flex items-center p-4 space-x-3">
            {/* Image Attachment */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-3 text-gray-500 hover:text-emerald-600 hover:bg-emerald-100 rounded-xl transition-all duration-200 group flex-shrink-0"
              title="Upload image"
            >
              <ImageIcon className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />

            {/* File Attachment */}
            <button
              onClick={() => docInputRef.current?.click()}
              className="p-3 text-gray-500 hover:text-blue-600 hover:bg-blue-100 rounded-xl transition-all duration-200 group flex-shrink-0"
              title="Upload file"
            >
              <Paperclip className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </button>
            <input
              ref={docInputRef}
              type="file"
              accept=".pdf,.doc,.docx,.txt,.csv"
              onChange={handleFileUpload}
              className="hidden"
            />
            
            {/* Text Input */}
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                placeholder={isRecording ? "Listening... Speak now" : "Ask farming questions..."}
                className="w-full bg-transparent border-none outline-none resize-none text-gray-800 placeholder-gray-400 text-sm leading-relaxed py-3"
                rows={1}
                style={{ minHeight: '48px', maxHeight: '120px' }}
                disabled={isTyping}
              />
            </div>
            
            {/* Voice Button */}
            <button
              onClick={handleVoiceToggle}
              disabled={!speechSupported}
              className={`p-3 rounded-xl transition-all duration-200 flex-shrink-0 ${
                isRecording 
                  ? 'bg-red-500 text-white shadow-lg shadow-red-500/25 animate-pulse' 
                  : speechSupported
                  ? 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-100'
                  : 'text-gray-300 cursor-not-allowed'
              }`}
              title={
                !speechSupported 
                  ? 'Voice input not supported' 
                  : isRecording 
                  ? 'Stop recording' 
                  : 'Start voice recording'
              }
            >
              {isRecording ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>
            
            {/* Send Button */}
            <button
              onClick={onSendMessage}
              disabled={(!message.trim() && !uploadedImage && !uploadedFile) || isTyping}
              className={`p-3 rounded-xl transition-all duration-200 transform flex-shrink-0 ${
                (message.trim() || uploadedImage || uploadedFile) && !isTyping
                  ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-white shadow-lg shadow-emerald-500/25 hover:shadow-xl hover:scale-105' 
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
              title="Send message"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
          
          {/* Recording Indicator */}
          {isRecording && (
            <div className="px-4 pb-4">
              <div className="flex items-center justify-center">
                <div className="flex items-center space-x-3 bg-gradient-to-r from-red-500 to-pink-500 text-white px-6 py-3 rounded-full shadow-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                  <span className="text-sm font-semibold">Recording... Speak clearly</span>
                  <div className="text-xs opacity-75 ml-2">
                    {speechSupported ? 'Click mic to stop' : 'Not supported'}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Quick Actions */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center space-x-4">
            <button className="text-xs text-gray-500 hover:text-emerald-600 transition-colors duration-200 font-medium">
              💡 Quick tips
            </button>
            <button className="text-xs text-gray-500 hover:text-emerald-600 transition-colors duration-200 font-medium">
              🌾 Crop diseases
            </button>
            <button className="text-xs text-gray-500 hover:text-emerald-600 transition-colors duration-200 font-medium">
              🌡️ Weather alerts
            </button>
            {!speechSupported && (
              <span className="text-xs text-orange-500 font-medium">
                ⚠️ Voice input requires Chrome/Edge/Safari
              </span>
            )}
          </div>
          
          {/* Disclaimer */}
          <div className="text-xs text-gray-400">
            FarmAssist AI provides guidance based on agricultural best practices
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;

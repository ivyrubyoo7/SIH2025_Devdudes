import React from 'react';
import { 
  Search, 
  Settings, 
  Share2,
  FileText,
  Wheat,
  Bell,
  User
} from 'lucide-react';

const backgroundPatternUrl = "data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.05%22%3E%3Cpath d=%22M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E";

const ChatHeader = () => {
  return (
    <header className="relative bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 shadow-xl">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-black/10">
        <div 
          className="absolute inset-0 opacity-30"
          style={{ backgroundImage: `url("${backgroundPatternUrl}")` }}
        ></div>
      </div>
      
      <div className="relative p-6">
        <div className="flex items-center justify-between">
          {/* Logo and Title Section */}
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-16 h-16 bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/20 shadow-lg">
                <Wheat className="h-8 w-8 text-white drop-shadow-sm" />
              </div>
              
            </div>
            <div className="text-white">
              <h1 className="text-2xl font-bold tracking-tight">
                FarmAssist AI
              </h1>
              <p className="text-emerald-100 text-sm font-medium">
                Your intelligent farming companion
              </p>
              
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <button className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 group">
              <Bell className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </button>
            <button className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 group">
              <Search className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </button>
            <button className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 group">
              <FileText className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </button>
            <button className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 group">
              <Share2 className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </button>
            <div className="w-px h-6 bg-white/20 mx-2"></div>
            <button className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 group">
              <User className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </button>
            <button className="p-3 hover:bg-white/10 rounded-xl transition-all duration-200 group">
              <Settings className="h-5 w-5 text-white group-hover:scale-110 transition-transform" />
            </button>
          </div>
        </div>

      </div>
    </header>
  );
};

export default ChatHeader;
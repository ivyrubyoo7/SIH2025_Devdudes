# voice_advisor.py (FINAL, FIXED with Voice Reader + Image Support)

import os
import streamlit as st
import pandas as pd
import time
import sqlite3
import tempfile
import io
from pydub import AudioSegment
from gtts import gTTS   # ✅ Text-to-Speech

from google import genai
from google.genai import types as genai_types  # ✅ for image/file parts
from dotenv import load_dotenv
from PyPDF2 import PdfReader 
import whisper   # pip install -U openai-whisper

# --- Config ---
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

PRIMARY_AI_MODEL = "gemini-2.5-pro"
DB_NAME = "farmer_support.db"
MAX_DOCUMENT_PAGES = 50

# --- Landing Page Language Selection ---
if "language_selected" not in st.session_state:
    st.session_state.language_selected = False
if "current_language" not in st.session_state:
    st.session_state.current_language = None

if not st.session_state.language_selected:
    st.markdown(
        """
        <style>
        .lang-option {padding: 30px; border: 2px solid #0d47a1; border-radius: 15px;
        text-align: center; cursor: pointer; background-color: #f5faff;}
        .lang-option:hover {background-color: #0d47a1; color: white;}
        </style>
        """,
        unsafe_allow_html=True
    )
    st.markdown("<h2 style='text-align:center;'>🌐 CHOOSE YOUR LANGUAGE</h2>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("English", use_container_width=True):
            st.session_state.current_language = "English"
            st.session_state.language_selected = True
            st.rerun()
        st.caption("For Indian farmers comfortable in English.")
    with col2:
        if st.button("മലയാളം", use_container_width=True):
            st.session_state.current_language = "Malayalam"
            st.session_state.language_selected = True
            st.rerun()
        st.caption("കേരളത്തിലെ കർഷകർക്ക്")
    with col3:
        if st.button("हिन्दी", use_container_width=True):
            st.session_state.current_language = "Hindi"
            st.session_state.language_selected = True
            st.rerun()
        st.caption("भारत के हिंदी भाषी किसानो के लिए")
    st.stop()

# --- DB Setup ---
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS escalations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_query TEXT,
            escalation_reason TEXT,
            ai_suggestion TEXT,
            location TEXT,
            image_uploaded BOOLEAN,
            status TEXT,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()
init_db()

# --- Prompts ---
ANALYSIS_SYSTEM_PROMPT = """
You are a highly reliable 'Digital Krishi Officer' for Kerala, India.
Your task is to answer the user's question by analyzing the provided text, document (if available), or image (if available), and combining it with your local expertise.

**RULES:**
1. **Source:** Always prioritize factual information from any provided context (documents/images).
2. **Context:** Apply the advice to the Kerala context (e.g., climate, local crops).
3. **Language:** Respond entirely in the **{language}** language.
4. **If Information is Limited:** If the document/image does not provide a definitive answer, advise the user to consult a local officer.
"""

# --- Gemini Init ---
if not GEMINI_API_KEY:
    st.error("GEMINI_API_KEY not found. Please create a .env file and set the key.")
    st.stop()
try:
    client = genai.Client(api_key=GEMINI_API_KEY)
except Exception as e:
    st.error(f"Error initializing Gemini client: {e}")
    st.stop()

# --- Utility: Entity extraction ---
def extract_entities(text: str):
    text_lower = text.lower()
    entities = []
    if "rice" in text_lower or "paddy" in text_lower: entities.append("crop: rice")
    if "banana" in text_lower or "vazha" in text_lower: entities.append("crop: banana")
    if "yellow" in text_lower or "yellowing" in text_lower: entities.append("symptom: yellowing")
    if "spot" in text_lower or "spots" in text_lower: entities.append("symptom: leaf spot")
    if "nitrogen" in text_lower: entities.append("cause: nitrogen deficiency")
    if "pest" in text_lower or "insect" in text_lower: entities.append("issue: pest attack")
    return entities

# --- Final Query Builder ---
def build_final_query(user_query, uploaded_file, camera_file, voice_text, language):
    pdf_text = ""
    if uploaded_file and uploaded_file.type == "application/pdf":
        pdf_reader = PdfReader(uploaded_file)
        for i, page in enumerate(pdf_reader.pages):
            if i < MAX_DOCUMENT_PAGES:
                pdf_text += page.extract_text() or ""

    image_context = ""
    if uploaded_file and uploaded_file.type.startswith("image/"):
        image_context = "Farmer uploaded an image of the crop."
    if camera_file:
        image_context = "Farmer captured a photo of the crop via camera."

    final_query = f"""
Farmer Written Question: {user_query or 'No manual question entered'}
Voice Transcript: {voice_text or 'No voice input'}
PDF Extracted Text: {pdf_text[:2000] if pdf_text else 'No PDF uploaded'}
Image Context: {image_context or 'No image provided'}
Please respond in {language}.
"""
    return final_query

# --- Unified Analysis ---
def get_unified_analysis(uploaded_file, query_text: str, language: str, camera_file=None) -> str:
    contents = []
    formatted_prompt = ANALYSIS_SYSTEM_PROMPT.format(language=language)
    contents.append(f"{formatted_prompt}\n\nUSER QUESTION: {query_text}")
    try:
        if uploaded_file and uploaded_file.type == "application/pdf":
            pdf_reader = PdfReader(uploaded_file)
            document_text = ""
            for i, page in enumerate(pdf_reader.pages):
                if i < MAX_DOCUMENT_PAGES:
                    document_text += page.extract_text() or ""
            contents.insert(0, f"DOCUMENT CONTENT (for context): {document_text[:5000]}...")
        if uploaded_file and uploaded_file.type.startswith("image/"):
            image_bytes = uploaded_file.getvalue()
            image_part = genai_types.Part.from_bytes(image_bytes, mime_type=uploaded_file.type)  # ✅ FIX
            contents.insert(0, image_part)
        if camera_file is not None:
            cam_bytes = camera_file.getvalue()
            cam_part = genai_types.Part.from_bytes(cam_bytes, mime_type="image/png")  # ✅ FIX
            contents.insert(0, cam_part)
    except Exception as e:
        return f"Error processing files: {e}"
    try:
        response = client.models.generate_content(model=PRIMARY_AI_MODEL, contents=contents)
        return response.text
    except Exception as e:
        return f"**API Connection Error:** Could not connect to Gemini. Details: {e}"

# --- Whisper model cache & helpers ---
@st.cache_resource
def load_whisper_model_cached(model_name="small"):
    return whisper.load_model(model_name)

def save_audio_bytes_to_wav(audio_bytes: bytes) -> str:
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    try:
        audio = AudioSegment.from_file(io.BytesIO(audio_bytes))
        if len(audio) == 0:
            raise ValueError("No audio detected in recording.")
        audio.export(tmp.name, format="wav")
    finally:
        tmp.close()
    return tmp.name

# --- TTS Helper ---
def text_to_speech(text: str, lang_code="en"):
    try:
        tts = gTTS(text=text, lang=lang_code)
        tmp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
        tts.save(tmp_file.name)
        return tmp_file.name
    except Exception as e:
        st.error(f"TTS Error: {e}")
        return None

# --- st.audio_input ---
def handle_streamlit_audio_input(lang_choice: str):
    auto_detect = st.checkbox("Auto-detect language (recommended)", value=True)
    audio_input = st.audio_input("Click and speak", key="mic_input")
    if audio_input is None:
        st.info("Waiting for microphone input...")
        return
    audio_bytes = audio_input.read()
    if not audio_bytes:
        st.error("Couldn't read audio.")
        return
    whisper_model = load_whisper_model_cached("small")
    path = save_audio_bytes_to_wav(audio_bytes)
    try:
        if auto_detect:
            result = whisper_model.transcribe(path)
        else:
            lang_map = {"English": "en", "Hindi": "hi", "Malayalam": "ml"}
            code = lang_map.get(lang_choice, None)
            result = whisper_model.transcribe(path, language=code) if code else whisper_model.transcribe(path)
        text = result.get("text", "").strip()
        if text:
            st.success("Transcription complete.")
            st.markdown(f"**Transcribed:** {text}")
            st.session_state.chat_input_value = text
            st.session_state.voice_entities = ", ".join(extract_entities(text))
    except Exception as e:
        st.error(f"Error during transcription: {e}")
    finally:
        os.remove(path)

# --- Farmer View ---
def render_farmer_view(lang_map):
    st.title(f"🌱 {lang_map['APP_TITLE']}")
    st.caption(lang_map['APP_CAPTION'])

    with st.sidebar:
        st.header("System Status")
        st.success(f"✅ AI Ready ({PRIMARY_AI_MODEL})")
        uploaded_file = st.file_uploader(lang_map['FILE_UPLOAD'], type=['pdf','jpg','jpeg','png'])
        if uploaded_file:
            st.session_state.uploaded_file = uploaded_file
            st.info(f"File ready: {uploaded_file.name}")

    # --- VOICE INPUT ---
    st.subheader(f"🎙️ {lang_map['VOICE_INPUT']}")
    if st.session_state.get("mic_ui_mode", "IDLE") == "IDLE":
        if st.button(lang_map['BUTTON_START']):
            st.session_state.mic_ui_mode = "RECORDING"
            st.rerun()
    elif st.session_state.get("mic_ui_mode") == "RECORDING":
        handle_streamlit_audio_input(st.session_state.current_language)
        if st.button("⏹ Stop Recording"):
            st.session_state.mic_ui_mode = "IDLE"
            st.rerun()

    if st.session_state.get("chat_input_value") and st.session_state.get("mic_ui_mode") == "IDLE":
        st.markdown(f"**Text:** *{st.session_state.chat_input_value}*")
        st.markdown(f"**Entities:** `{st.session_state.voice_entities}`")

    # --- CAMERA INPUT ---
    st.subheader("📷 Capture Crop Image")
    if "show_camera" not in st.session_state:
        st.session_state.show_camera = False
    if not st.session_state.show_camera:
        if st.button("📸 Open Camera"):
            st.session_state.show_camera = True
            st.rerun()
    else:
        camera_file = st.camera_input("Take a photo")
        if camera_file:
            st.success("✅ Camera image captured!")
            st.session_state.camera_file = camera_file
        if st.button("Close Camera"):
            st.session_state.show_camera = False
            st.rerun()

    # --- WRITE QUERY ---
    with st.expander("📝 Write Your Query (optional)"):
        user_query = st.text_area(
            lang_map['INPUT_LABEL'],
            value=st.session_state.get("manual_query", "") or "",
            height=100
        )
        st.session_state.manual_query = user_query

    # --- Final Advisory ---
    camera_file = st.session_state.get("camera_file", None)
    uploaded_file = st.session_state.get("uploaded_file", None)
    voice_text = st.session_state.get("chat_input_value", "")

    if st.button(lang_map['BUTTON_ADVISORY']):
        final_query = build_final_query(
            st.session_state.manual_query,
            uploaded_file,
            camera_file,
            voice_text,
            st.session_state.current_language
        )
        with st.spinner("Analyzing..."):
            diagnosis = get_unified_analysis(uploaded_file, final_query, st.session_state.current_language, camera_file)
        st.session_state.last_answer = diagnosis  # ✅ persist

    # --- Always show last answer if available ---
    if st.session_state.get("last_answer"):
        st.subheader(f"👨‍🌾 {lang_map['OUTPUT_HEADER']}")
        st.markdown(st.session_state.last_answer)

        lang_codes = {"English": "en", "Hindi": "hi", "Malayalam": "ml"}
        tts_lang = lang_codes.get(st.session_state.current_language, "en")

        if st.button("🔊 Listen to Advice"):
            audio_path = text_to_speech(st.session_state.last_answer, lang_code=tts_lang)
            if audio_path:
                st.audio(audio_path, format="audio/mp3")

# --- Language Map ---
TEXT_MAP = {
    "Malayalam": {
        "APP_TITLE": "ഡിജിറ്റൽ കൃഷി ഓഫീസർ",
        "APP_CAPTION": "മൾട്ടിമോഡൽ ഉപദേശം",
        "SELECT_VIEW": "കാഴ്ച തിരഞ്ഞെടുക്കുക",
        "VIEW_FARMER": "കർഷക ഉപദേശനം",
        "VIEW_OFFICER": "ഓഫീസർ ഡാഷ്ബോർഡ്",
        "ASK_QUESTION": "നിങ്ങളുടെ ചോദ്യം:",
        "INPUT_LABEL": "വോയ്സ് അല്ലെങ്കിൽ ടെക്സ്റ്റ്:",
        "PLACEHOLDER": "ഉദാ: എന്റെ വാഴക്ക് ഇലപ്പുള്ളി...",
        "BUTTON_ADVISORY": "ഉപദേശം നേടുക",
        "VOICE_INPUT": "വോയ്സ് ഇൻപുട്ട്",
        "BUTTON_START": "റെക്കോർഡ് ആരംഭിക്കുക",
        "OUTPUT_HEADER": "AI ഉപദേശം",
        "FILE_UPLOAD": "ഫയൽ അപ്ലോഡ് ചെയ്യുക",
    },
    "English": {
        "APP_TITLE": "Digital Krishi Officer",
        "APP_CAPTION": "Multimodal advisory with voice, camera & docs",
        "SELECT_VIEW": "Select View",
        "VIEW_FARMER": "Farmer Advisory",
        "VIEW_OFFICER": "Officer Dashboard",
        "ASK_QUESTION": "Ask your question:",
        "INPUT_LABEL": "Voice, Camera or Text:",
        "PLACEHOLDER": "e.g., My banana crop has leaf spot...",
        "BUTTON_ADVISORY": "Get Advisory",
        "VOICE_INPUT": "Voice Input",
        "BUTTON_START": "Start Recording",
        "OUTPUT_HEADER": "AI Advice",
        "FILE_UPLOAD": "Upload file",
    },
    "Hindi": {
        "APP_TITLE": "डिजिटल कृषि अधिकारी",
        "APP_CAPTION": "बहु-मॉडल सलाह",
        "SELECT_VIEW": "दृश्य चुनें",
        "VIEW_FARMER": "किसान सलाह",
        "VIEW_OFFICER": "अधिकारी डैशबोर्ड",
        "ASK_QUESTION": "अपना प्रश्न पूछें:",
        "INPUT_LABEL": "आवाज, कैमरा या टेक्स्ट:",
        "PLACEHOLDER": "उदा: मेरे धान के पत्ते पीले...",
        "BUTTON_ADVISORY": "सलाह प्राप्त करें",
        "VOICE_INPUT": "आवाज इनपुट",
        "BUTTON_START": "रिकॉर्डिंग शुरू करें",
        "OUTPUT_HEADER": "AI सलाह",
        "FILE_UPLOAD": "फ़ाइल अपलोड करें",
    }
}

# --- Main ---
if __name__ == "__main__":
    st.set_page_config(page_title="Digital Krishi Officer", layout="wide")
    selected_language = st.sidebar.radio("Choose output language:", ("Malayalam","English","Hindi"),
                                         index=("Malayalam","English","Hindi").index(st.session_state.current_language or "Malayalam"))
    st.session_state.current_language = selected_language
    lang_map = TEXT_MAP.get(selected_language, TEXT_MAP["Malayalam"])
    app_mode = st.sidebar.radio(lang_map['SELECT_VIEW'], (lang_map['VIEW_FARMER'], lang_map['VIEW_OFFICER']))
    if app_mode == lang_map['VIEW_FARMER']:
        render_farmer_view(lang_map)
    else:
        st.info("👨‍💻 Officer dashboard temporarily disabled in this version.")

# realtime_speech.py
import streamlit as st
import whisper
import tempfile
import os

# ------------------------
# Load Whisper model once
# ------------------------
@st.cache_resource
def load_model():
    return whisper.load_model("base")

model = load_model()

# ------------------------
# Helper to save audio buffer
# ------------------------
def save_audio(audio_bytes):
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
        tmp.write(audio_bytes)
        return tmp.name

# ------------------------
# Streamlit UI
# ------------------------
st.title("🎙️ Real-Time Speech to Text (Streamlit + Whisper)")

st.write("Click and speak — text will appear below.")

# Streamlit experimental mic input
audio_input = st.audio_input("Speak here:")

# Store conversation transcript in session state
if "transcript" not in st.session_state:
    st.session_state.transcript = ""

if audio_input is not None:
    audio_bytes = audio_input.read()
    path = save_audio(audio_bytes)
    try:
        result = model.transcribe(path, language="en")
        text = result["text"].strip()
        if text:
            st.session_state.transcript += " " + text
    finally:
        os.remove(path)

# Show live transcript
st.subheader("📝 Transcript")
st.write(st.session_state.transcript if st.session_state.transcript else "Waiting for speech...")

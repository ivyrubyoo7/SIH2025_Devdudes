# voice_advisor.py (FINAL, BUG-FREE, LOCALIZED CODE)
# Streamlit mic input (st.audio_input) + Camera + Whisper + Gemini
# Farmers can: speak, write, upload files, or capture images.

import os
import streamlit as st
import pandas as pd
import time
import sqlite3
import tempfile

from google import genai
from google.genai.errors import APIError
from dotenv import load_dotenv
from PyPDF2 import PdfReader 

import whisper   # pip install -U openai-whisper

# --- Config ---
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

PRIMARY_AI_MODEL = "gemini-2.5-pro"
DB_NAME = "farmer_support.db"
MAX_DOCUMENT_PAGES = 50

# --- Landing Page Language Selection ---
if "language_selected" not in st.session_state:
    st.session_state.language_selected = False
if "current_language" not in st.session_state:
    st.session_state.current_language = None

if not st.session_state.language_selected:
    st.markdown(
        """
        <style>
        .lang-option {padding: 30px; border: 2px solid #0d47a1; border-radius: 15px;
        text-align: center; cursor: pointer; background-color: #f5faff;}
        .lang-option:hover {background-color: #0d47a1; color: white;}
        </style>
        """,
        unsafe_allow_html=True
    )
    st.markdown("<h2 style='text-align:center;'>🌐 CHOOSE YOUR LANGUAGE</h2>", unsafe_allow_html=True)
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("English", use_container_width=True):
            st.session_state.current_language = "English"
            st.session_state.language_selected = True
            st.rerun()
        st.caption("For Indian farmers comfortable in English.")
    with col2:
        if st.button("മലയാളം", use_container_width=True):
            st.session_state.current_language = "Malayalam"
            st.session_state.language_selected = True
            st.rerun()
        st.caption("കേരളത്തിലെ കർഷകർക്ക്")
    with col3:
        if st.button("हिन्दी", use_container_width=True):
            st.session_state.current_language = "Hindi"
            st.session_state.language_selected = True
            st.rerun()
        st.caption("भारत के हिंदी भाषी किसानो के लिए")
    st.stop()

# --- DB Setup ---
def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS escalations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            farmer_query TEXT,
            escalation_reason TEXT,
            ai_suggestion TEXT,
            location TEXT,
            image_uploaded BOOLEAN,
            status TEXT,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()
init_db()

# --- Prompts ---
ANALYSIS_SYSTEM_PROMPT = """
You are a highly reliable 'Digital Krishi Officer' for Kerala, India.
Your task is to answer the user's question by analyzing the provided text, document (if available), or image (if available), and combining it with your local expertise.

**RULES:**
1. **Source:** Always prioritize factual information from any provided context (documents/images).
2. **Context:** Apply the advice to the Kerala context (e.g., climate, local crops).
3. **Language:** Respond entirely in the **{language}** language.
4. **If Information is Limited:** If the document/image does not provide a definitive answer, advise the user to consult a local officer.
"""

# --- Gemini Init ---
if not GEMINI_API_KEY:
    st.error("GEMINI_API_KEY not found. Please create a .env file and set the key.")
    st.stop()
try:
    client = genai.Client(api_key=GEMINI_API_KEY)
except Exception as e:
    st.error(f"Error initializing Gemini client: {e}")
    st.stop()

# --- Utility: Entity extraction ---
def extract_entities(text: str):
    text_lower = text.lower()
    entities = []
    if "rice" in text_lower or "paddy" in text_lower: entities.append("crop: rice")
    if "banana" in text_lower or "vazha" in text_lower: entities.append("crop: banana")
    if "yellow" in text_lower or "yellowing" in text_lower: entities.append("symptom: yellowing")
    if "spot" in text_lower or "spots" in text_lower: entities.append("symptom: leaf spot")
    if "nitrogen" in text_lower: entities.append("cause: nitrogen deficiency")
    if "pest" in text_lower or "insect" in text_lower: entities.append("issue: pest attack")
    return entities

# --- Unified Analysis ---
def get_unified_analysis(uploaded_file, query_text: str, language: str, camera_file=None) -> str:
    contents = []
    formatted_prompt = ANALYSIS_SYSTEM_PROMPT.format(language=language)
    contents.append(f"{formatted_prompt}\n\nUSER QUESTION: {query_text}")
    try:
        # PDF Upload
        if uploaded_file and uploaded_file.type == "application/pdf":
            pdf_reader = PdfReader(uploaded_file)
            document_text = ""
            for i, page in enumerate(pdf_reader.pages):
                if i < MAX_DOCUMENT_PAGES:
                    document_text += page.extract_text() or ""
            contents.insert(0, f"DOCUMENT CONTENT (for context): {document_text[:5000]}...")
        # Image Upload
        if uploaded_file and uploaded_file.type.startswith("image/"):
            image_bytes = uploaded_file.getvalue()
            contents.insert(0, {"mime_type": uploaded_file.type, "data": image_bytes})
        # Camera Capture
        if camera_file is not None:
            cam_bytes = camera_file.getvalue()
            contents.insert(0, {"mime_type": "image/png", "data": cam_bytes})
    except Exception as e:
        return f"Error processing files: {e}"
    try:
        response = client.models.generate_content(model=PRIMARY_AI_MODEL, contents=contents)
        return response.text
    except Exception as e:
        return f"**API Connection Error:** Could not connect to Gemini. Details: {e}"

# --- DB Helpers ---
def log_escalation_ticket(query, reason, image_uploaded, ai_suggestion="AI suggested on-site visit"):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    current_time = time.strftime("%Y-%m-%d %H:%M:%S")
    status = 'OPEN'; location = "Palakkad, Kerala (Assumed)"
    c.execute("""
        INSERT INTO escalations (farmer_query, escalation_reason, ai_suggestion, location, image_uploaded, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (query, reason, ai_suggestion, location, image_uploaded, status, current_time))
    conn.commit()
    conn.close()
    st.toast("Escalation ticket filed!", icon="🚨")

def get_escalations():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM escalations ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def update_status(escalation_id, new_status):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("UPDATE escalations SET status = ? WHERE id = ?", (new_status, escalation_id))
    conn.commit()
    conn.close()

def render_officer_dashboard():
    lang_map = TEXT_MAP.get(st.session_state.current_language, TEXT_MAP["Malayalam"])
    st.header("🧑‍💻 Digital Krishi Officer Dashboard")
    st.subheader("Pending Escalation Tickets")
    rows = get_escalations()
    if not rows:
        st.info("✅ No escalation tickets filed yet."); return
    df_escalation = pd.DataFrame(rows)
    df_display = df_escalation.sort_values(by=['status', 'created_at'], ascending=[False, False])
    st.dataframe(df_display, use_container_width=True, height=300)
    st.subheader("Action Center")
    open_tickets = df_display[df_display['status'] == 'OPEN']['id'].unique()
    if len(open_tickets) == 0: st.info("All open tickets resolved."); return
    selected_id = st.selectbox("Select Ticket ID to Resolve:", open_tickets)
    if selected_id:
        ticket_data = df_display[df_display['id'] == selected_id].iloc[0]
        st.markdown(f"**Farmer Query:** {ticket_data['farmer_query']}")
        st.markdown(f"**Reason:** :red[{ticket_data['escalation_reason']}]")
        if st.button("✅ Mark as RESOLVED"):
            update_status(selected_id, "RESOLVED")
            st.success(f"Ticket #{selected_id} resolved.")
            st.rerun()

# --- Whisper model cache & helpers ---
@st.cache_resource
def load_whisper_model_cached(model_name="small"):
    return whisper.load_model(model_name)

def save_audio_bytes_to_wav(audio_bytes: bytes) -> str:
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".wav")
    try:
        tmp.write(audio_bytes)
        tmp.flush()
    finally:
        tmp.close()
    return tmp.name

# --- st.audio_input based recording & transcription ---
def handle_streamlit_audio_input(lang_choice: str):
    st.markdown("### 🎤 Voice input (microphone)")
    auto_detect = st.checkbox("Auto-detect language (recommended)", value=True)
    audio_input = st.audio_input("Click and speak", key="mic_input")
    if audio_input is None:
        st.info("Waiting for microphone input...")
        return
    audio_bytes = audio_input.read()
    if not audio_bytes:
        st.error("Couldn't read audio.")
        return
    whisper_model = load_whisper_model_cached("small")
    path = save_audio_bytes_to_wav(audio_bytes)
    try:
        if auto_detect:
            result = whisper_model.transcribe(path)
        else:
            lang_map = {"English": "en", "Hindi": "hi", "Malayalam": "ml"}
            code = lang_map.get(lang_choice, None)
            result = whisper_model.transcribe(path, language=code) if code else whisper_model.transcribe(path)
        text = result.get("text", "").strip()
        if text:
            st.success("Transcription complete.")
            st.markdown(f"**Transcribed:** {text}")
            st.session_state.chat_input_value = text
            st.session_state.voice_entities = ", ".join(extract_entities(text))
    except Exception as e:
        st.error(f"Error during transcription: {e}")
    finally:
        os.remove(path)

# --- Farmer View ---
def render_farmer_view(lang_map):
    st.title(f"🌱 {lang_map['APP_TITLE']}")
    st.caption(lang_map['APP_CAPTION'])
    with st.sidebar:
        st.header("System Status"); st.success(f"✅ AI Ready ({PRIMARY_AI_MODEL})")
        st.subheader(f"🎙️ {lang_map['VOICE_INPUT']}")
        if st.session_state.get("mic_ui_mode", "IDLE") == "IDLE":
            if st.button(lang_map['BUTTON_START']):
                st.session_state.mic_ui_mode = "RECORDING"
                st.rerun()
        if st.session_state.get("mic_ui_mode") == "RECORDING":
            handle_streamlit_audio_input(st.session_state.current_language)
            if st.button("Stop Recording"):
                st.session_state.mic_ui_mode = "IDLE"
                st.rerun()
        if st.session_state.get("chat_input_value") and st.session_state.get("mic_ui_mode") == "IDLE":
            st.markdown(f"**Text:** *{st.session_state.chat_input_value}*")
            st.markdown(f"**Entities:** `{st.session_state.voice_entities}`")
        # File upload
        uploaded_file = st.file_uploader(lang_map['FILE_UPLOAD'], type=['pdf','jpg','jpeg','png'])
        if uploaded_file: st.info(f"File ready: {uploaded_file.name}")
        # Camera input
        camera_file = st.camera_input("📷 Capture crop image")
        if camera_file: st.success("Camera image captured!")
    # Text input
    st.subheader(lang_map['ASK_QUESTION'])
    user_query = st.text_area(lang_map['INPUT_LABEL'],
                              value=st.session_state.get("chat_input_value", "") or lang_map['PLACEHOLDER'], height=100)
    st.session_state.chat_input_value = user_query
    if st.button(lang_map['BUTTON_ADVISORY']) and (user_query or uploaded_file or camera_file):
        final_query = user_query or f"Analyze the uploaded/captured file. Respond in {st.session_state.current_language}."
        with st.spinner("Analyzing..."):
            diagnosis = get_unified_analysis(uploaded_file, final_query, st.session_state.current_language, camera_file)
        st.session_state.last_answer = diagnosis
        st.subheader(f"👨‍🌾 {lang_map['OUTPUT_HEADER']}"); st.markdown(diagnosis)

# --- Language Map ---
TEXT_MAP = {
    "Malayalam": {
        "APP_TITLE": "ഡിജിറ്റൽ കൃഷി ഓഫീസർ",
        "APP_CAPTION": "മൾട്ടിമോഡൽ ഉപദേശം",
        "SELECT_VIEW": "കാഴ്ച തിരഞ്ഞെടുക്കുക",
        "VIEW_FARMER": "കർഷക ഉപദേശനം",
        "VIEW_OFFICER": "ഓഫീസർ ഡാഷ്ബോർഡ്",
        "ASK_QUESTION": "നിങ്ങളുടെ ചോദ്യം:",
        "INPUT_LABEL": "വോയ്സ് അല്ലെങ്കിൽ ടെക്സ്റ്റ്:",
        "PLACEHOLDER": "ഉദാ: എന്റെ വാഴക്ക് ഇലപ്പുള്ളി...",
        "BUTTON_ADVISORY": "ഉപദേശം നേടുക",
        "VOICE_INPUT": "വോയ്സ് ഇൻപുട്ട്",
        "BUTTON_START": "റെക്കോർഡ് ആരംഭിക്കുക",
        "OUTPUT_HEADER": "AI ഉപദേശം",
        "FILE_UPLOAD": "ഫയൽ അപ്ലോഡ് ചെയ്യുക",
    },
    "English": {
        "APP_TITLE": "Digital Krishi Officer",
        "APP_CAPTION": "Multimodal advisory with voice, camera & docs",
        "SELECT_VIEW": "Select View",
        "VIEW_FARMER": "Farmer Advisory",
        "VIEW_OFFICER": "Officer Dashboard",
        "ASK_QUESTION": "Ask your question:",
        "INPUT_LABEL": "Voice, Camera or Text:",
        "PLACEHOLDER": "e.g., My banana crop has leaf spot...",
        "BUTTON_ADVISORY": "Get Advisory",
        "VOICE_INPUT": "Voice Input",
        "BUTTON_START": "Start Recording",
        "OUTPUT_HEADER": "AI Advice",
        "FILE_UPLOAD": "Upload file",
    },
    "Hindi": {
        "APP_TITLE": "डिजिटल कृषि अधिकारी",
        "APP_CAPTION": "बहु-मॉडल सलाह",
        "SELECT_VIEW": "दृश्य चुनें",
        "VIEW_FARMER": "किसान सलाह",
        "VIEW_OFFICER": "अधिकारी डैशबोर्ड",
        "ASK_QUESTION": "अपना प्रश्न पूछें:",
        "INPUT_LABEL": "आवाज, कैमरा या टेक्स्ट:",
        "PLACEHOLDER": "उदा: मेरे धान के पत्ते पीले...",
        "BUTTON_ADVISORY": "सलाह प्राप्त करें",
        "VOICE_INPUT": "आवाज इनपुट",
        "BUTTON_START": "रिकॉर्डिंग शुरू करें",
        "OUTPUT_HEADER": "AI सलाह",
        "FILE_UPLOAD": "फ़ाइल अपलोड करें",
    }
}

# --- Main ---
if __name__ == "__main__":
    st.set_page_config(page_title="Digital Krishi Officer", layout="wide")
    selected_language = st.sidebar.radio("Choose output language:", ("Malayalam","English","Hindi"),
                                         index=("Malayalam","English","Hindi").index(st.session_state.current_language or "Malayalam"))
    st.session_state.current_language = selected_language
    lang_map = TEXT_MAP.get(selected_language, TEXT_MAP["Malayalam"])
    app_mode = st.sidebar.radio(lang_map['SELECT_VIEW'], (lang_map['VIEW_FARMER'], lang_map['VIEW_OFFICER']))
    if app_mode == lang_map['VIEW_FARMER']:
        render_farmer_view(lang_map)
    else:
        render_officer_dashboard()

// src/hooks/useChat.js
import { useState, useCallback } from 'react';

// Backend API base URL
const API_BASE_URL = 'http://localhost:5000';

export const useChat = () => {
  const [chatHistory, setChatHistory] = useState([
    {
      id: 1,
      type: 'system',
      content: 'Welcome to FarmAssist AI! 🌱\n\nI\'m here to help you with:\n• Crop disease identification\n• Soil health analysis\n• Weather and irrigation advice\n• Pest management strategies\n• Fertilizer recommendations\n• Harvest timing guidance\n\nYou can ask questions through text, voice, or by uploading images of your crops or fields.',
      timestamp: new Date().toISOString(),
    }
  ]);
  
  const [isTyping, setIsTyping] = useState(false);

  // Send message with image, file, or audio
  const sendMessage = useCallback(async (messageText, image, uploadedFile, recordedAudio, uploadedAudio) => {
    if (!messageText.trim() && !image && !uploadedFile && !recordedAudio && !uploadedAudio) return;

    // Add user message
    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: messageText,
      image: image,
      file: uploadedFile,
      recordedAudio: recordedAudio,
      uploadedAudio: uploadedAudio,
      timestamp: new Date().toISOString(),
    };

    setChatHistory(prev => [...prev, userMessage]);

    // Show typing indicator
    setIsTyping(true);

    try {
      let aiResponse;

      if (image) {
        // Handle image analysis
        aiResponse = await handleImageAnalysis(image, messageText);
      } else if (recordedAudio || uploadedAudio) {
        // Handle audio analysis
        const audioToProcess = recordedAudio || uploadedAudio;
        aiResponse = await handleAudioAnalysis(audioToProcess, messageText);
      } else if (messageText.trim()) {
        // Handle text query
        aiResponse = await handleTextQuery(messageText);
      }

      // Add AI response to chat
      setChatHistory(prev => [...prev, aiResponse]);
      
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Add error message
      const errorMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: 'I apologize, but I encountered an error processing your request. Please try again or contact support if the issue persists.',
        context: 'Error',
        confidence: '0%',
        timestamp: new Date().toISOString(),
        error: true
      };
      
      setChatHistory(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  }, []);

  // Handle audio analysis
  const handleAudioAnalysis = async (audioData, messageText) => {
    try {
      // If it's a recorded audio object, use the blob
      let audioFile = audioData;
      if (audioData.blob) {
        audioFile = audioData.blob;
      }
      
      // Create form data
      const formData = new FormData();
      formData.append('audio', audioFile, audioData.name || 'audio.webm');
      if (messageText) {
        formData.append('query', messageText);
      }
      
      // Send to backend
      const response = await fetch(`${API_BASE_URL}/process-audio`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      // Format response content
      let content = `🎤 **Audio Processing Complete**\n\n`;
      
      if (result.transcript) {
        content += `**Transcript:** ${result.transcript}\n\n`;
      }
      
      if (result.answer) {
        content += result.answer;
      }
      
      // Add entities information if available
      if (result.entities && result.entities.length > 0) {
        content += `\n\n**Detected Information:**\n`;
        result.entities.forEach(entity => {
          content += `• ${entity.replace(':', ': ')}\n`;
        });
      }
      
      if (result.escalation_recommended) {
        content += `\n\n⚠️ ${result.message}`;
      }
      
      return {
        id: Date.now() + 1,
        type: 'assistant',
        content: content,
        context: result.context || 'Audio Analysis',
        confidence: `${Math.round((result.confidence || 0) * 100)}%`,
        timestamp: new Date().toISOString(),
        escalationRecommended: result.escalation_recommended || false,
        audioData: result
      };
      
    } catch (error) {
      console.error('Audio analysis error:', error);
      
      // Fallback: Just acknowledge the audio was received
      return {
        id: Date.now() + 1,
        type: 'assistant',
        content: `🎤 **Audio Received**\n\nI received your audio recording${messageText ? ` and message: "${messageText}"` : ''}. However, I'm unable to process the audio at the moment due to a backend issue. Please try transcribing your message as text, and I'll be happy to help!`,
        context: 'Audio Reception',
        timestamp: new Date().toISOString(),
      };
    }
  };

  // Handle image analysis
  const handleImageAnalysis = async (imageData, messageText) => {
    try {
      // Convert base64 image to blob
      const base64Data = imageData.split(',')[1];
      const byteCharacters = atob(base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'image/jpeg' });
      
      // Create form data
      const formData = new FormData();
      formData.append('image', blob, 'crop_image.jpg');
      if (messageText) {
        formData.append('query', messageText);
      }
      
      // Send to backend
      const response = await fetch(`${API_BASE_URL}/analyze-image`, {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      // Format response content
      let content = `🔍 **Image Analysis Complete**\n\n`;
      content += `**Disease Detected:** ${result.disease_detected || 'Unknown'}\n`;
      content += `**Confidence:** ${Math.round((result.confidence || 0) * 100)}%\n\n`;
      
      if (result.recommendations && result.recommendations.length > 0) {
        content += `**Recommendations:**\n`;
        result.recommendations.forEach(rec => {
          content += `• ${rec}\n`;
        });
      }
      
      if (result.escalation_recommended) {
        content += `\n⚠️ ${result.message}\n\nWould you like me to connect you with an agricultural expert?`;
      }
      
      return {
        id: Date.now() + 1,
        type: 'assistant',
        content: content,
        context: 'Disease Analysis',
        confidence: `${Math.round((result.confidence || 0) * 100)}%`,
        timestamp: new Date().toISOString(),
        escalationRecommended: result.escalation_recommended || false,
        analysisData: result
      };
      
    } catch (error) {
      console.error('Image analysis error:', error);
      throw error;
    }
  };

  // Handle text query
  const handleTextQuery = async (query) => {
    try {
      const response = await fetch(`${API_BASE_URL}/chat-query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query }),
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const result = await response.json();
      
      // Format response content
      let content = result.answer;
      
      // Add entities information if available
      if (result.entities && result.entities.length > 0) {
        content += `\n\n**Detected Information:**\n`;
        result.entities.forEach(entity => {
          content += `• ${entity.replace(':', ': ')}\n`;
        });
      }
      
      // Add sources if available
      if (result.sources && result.sources.length > 0) {
        content += `\n\n**Sources:**\n`;
        result.sources.forEach((source, index) => {
          content += `${index + 1}. ${source.source} (Page ${source.page})\n`;
        });
      }
      
      if (result.escalation_recommended) {
        content += `\n\n⚠️ ${result.message}`;
      }
      
      return {
        id: Date.now() + 1,
        type: 'assistant',
        content: content,
        context: result.context || 'General Farming',
        confidence: `${Math.round((result.confidence || 0) * 100)}%`,
        timestamp: new Date().toISOString(),
        escalationRecommended: result.escalation_recommended || false,
        entities: result.entities || [],
        sources: result.sources || []
      };
      
    } catch (error) {
      console.error('Text query error:', error);
      throw error;
    }
  };

  // Handle feedback
  const handleFeedback = useCallback(async (messageId, feedbackType) => {
    try {
      // Find the message
      const message = chatHistory.find(msg => msg.id === messageId);
      if (!message) return;
      
      // Find the corresponding user query
      const messageIndex = chatHistory.findIndex(msg => msg.id === messageId);
      const userMessage = messageIndex > 0 ? chatHistory[messageIndex - 1] : null;
      
      const feedbackData = {
        query: userMessage?.content || '',
        answer: message.content || '',
        feedback: feedbackType,
        comment: ''
      };
      
      const response = await fetch(`${API_BASE_URL}/feedback`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
      });
      
      if (response.ok) {
        const feedbackMessage = feedbackType === 'helpful' 
          ? 'Thanks for your feedback! This helps us improve.' 
          : 'Thanks for letting us know. We\'ll work on improving our responses.';
        
        // Optional: Add a temporary system message
        const systemMessage = {
          id: Date.now(),
          type: 'system',
          content: `✅ ${feedbackMessage}`,
          timestamp: new Date().toISOString(),
        };
        
        setChatHistory(prev => [...prev, systemMessage]);
        
        // Remove system message after 3 seconds
        setTimeout(() => {
          setChatHistory(prev => prev.filter(msg => msg.id !== systemMessage.id));
        }, 3000);
      }
      
    } catch (error) {
      console.error('Feedback submission error:', error);
      alert('Failed to submit feedback. Please try again.');
    }
  }, [chatHistory]);

  // Handle escalation
  const handleEscalate = useCallback(async (messageId) => {
    try {
      // Find the message and related data
      const message = chatHistory.find(msg => msg.id === messageId);
      const messageIndex = chatHistory.findIndex(msg => msg.id === messageId);
      const userMessage = messageIndex > 0 ? chatHistory[messageIndex - 1] : null;
      
      const escalationData = {
        query: userMessage?.content || '',
        prediction: message?.analysisData?.disease_detected || message?.context || '',
        confidence: message?.analysisData?.confidence || 0,
        location: 'User Location',
        weather: 'Current Weather',
        image_url: userMessage?.image || ''
      };
      
      const response = await fetch(`${API_BASE_URL}/escalate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(escalationData),
      });
      
      if (response.ok) {
        // Add system message about escalation
        const escalationMessage = {
          id: Date.now(),
          type: 'system',
          content: '🚨 **Escalating to Expert**\n\nConnecting you to an agricultural expert... Please hold while we find the best specialist for your query. An expert will join this conversation shortly.',
          timestamp: new Date().toISOString(),
        };
        
        setChatHistory(prev => [...prev, escalationMessage]);
        
        // Simulate expert connection
        setTimeout(() => {
          const expertMessage = {
            id: Date.now() + 1,
            type: 'assistant',
            content: '👨‍🌾 **Expert Connected**\n\nHello! I\'m Dr. Sarah Johnson, an agricultural specialist. I see you need expert assistance with your farming concern. I\'ve reviewed your query and I\'m here to provide detailed guidance.\n\nBased on the information provided, let me give you specific recommendations tailored to your situation. Please share any additional details about your crop, location, and current growing conditions so I can provide the most accurate advice.',
            context: 'Expert Consultation',
            confidence: '95%',
            timestamp: new Date().toISOString(),
            isExpert: true
          };
          setChatHistory(prev => [...prev, expertMessage]);
        }, 3000);
      }
      
    } catch (error) {
      console.error('Escalation error:', error);
      alert('Failed to escalate to expert. Please try again.');
    }
  }, [chatHistory]);

  // Process audio transcript (called from ChatInput)
  const processAudioTranscript = useCallback(async (transcript, entities) => {
    if (!transcript.trim()) return;
    
    // Add user message with transcript
    const userMessage = {
      id: Date.now(),
      type: 'user',
      content: transcript,
      isVoiceInput: true,
      entities: entities,
      timestamp: new Date().toISOString(),
    };

    setChatHistory(prev => [...prev, userMessage]);

    // Process as text query
    setIsTyping(true);
    
    try {
      const aiResponse = await handleTextQuery(transcript);
      setChatHistory(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Audio processing error:', error);
      const errorMessage = {
        id: Date.now() + 1,
        type: 'assistant',
        content: 'I encountered an error processing your voice input. Please try again.',
        context: 'Error',
        timestamp: new Date().toISOString(),
      };
      setChatHistory(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  }, []);

  return {
    chatHistory,
    isTyping,
    sendMessage,
    handleFeedback,
    handleEscalate,
    processAudioTranscript
  };
};
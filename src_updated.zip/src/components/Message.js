import React from 'react';
import { 
  CheckCircle,
  ThumbsUp,
  ThumbsDown,
  Phone,
  Copy,
  ExternalLink,
  Clock,
  Zap
} from 'lucide-react';


const Message = ({ message, onFeedback, onEscalate }) => {
  const isUser = message.type === 'user';
  const isSystem = message.type === 'system';
  const isAssistant = message.type === 'assistant';

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      // Optional: Show success message
      console.log('Message copied to clipboard');
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = message.content;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
    }
  };

  const formatTimestamp = (timestamp) => {
    try {
      return new Date(timestamp).toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
      });
    } catch (error) {
      return 'Now';
    }
  };

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-8 group`}>
      <div className={`max-w-4xl transition-all duration-300 ${
        isUser 
          ? 'bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-lg shadow-emerald-500/25' 
          : isSystem
          ? 'bg-gradient-to-br from-blue-50 to-indigo-100 text-blue-900 border border-blue-200 shadow-sm'
          : 'bg-white border border-gray-200 shadow-lg shadow-gray-900/5'
      } rounded-2xl overflow-hidden hover:shadow-xl transition-shadow`}>
        
        {/* Message Header for AI responses */}
        {isAssistant && (
          <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-6 py-3 border-b border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center">
                <Zap className="h-4 w-4 text-white" />
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 text-sm">FarmAssist AI</h4>
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <Clock className="h-3 w-3" />
                  <span>{formatTimestamp(message.timestamp)}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="p-6">
          {/* Message Image */}
          {message.image && (
            <div className="mb-4">
              <img 
                src={message.image} 
                alt="Uploaded content" 
                className="w-full max-w-md rounded-xl shadow-md hover:shadow-lg transition-shadow" 
              />
            </div>
          )}

          {/* Message Content */}
          <div className={`leading-relaxed whitespace-pre-wrap ${
            isUser ? 'text-white' : isSystem ? 'text-blue-900' : 'text-gray-800'
          }`}>
            {message.content}
          </div>

          {/* AI Response Metadata & Actions */}
          {(message.context || isAssistant) && (
            <div className="mt-6 pt-4 border-t border-gray-100">
              
              
              {/* Action Buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button 
                    onClick={() => onFeedback(message.id, 'helpful')}
                    className="flex items-center space-x-2 text-xs text-gray-600 hover:text-emerald-600 transition-colors duration-200 hover:bg-emerald-50 px-3 py-2 rounded-lg"
                  >
                    <ThumbsUp className="h-3 w-3" />
                    <span className="font-medium">Helpful</span>
                  </button>
                  <button 
                    onClick={() => onFeedback(message.id, 'not-helpful')}
                    className="flex items-center space-x-2 text-xs text-gray-600 hover:text-red-600 transition-colors duration-200 hover:bg-red-50 px-3 py-2 rounded-lg"
                  >
                    <ThumbsDown className="h-3 w-3" />
                    <span className="font-medium">Not helpful</span>
                  </button>
                  <button 
                    onClick={() => onEscalate(message.id)}
                    className="flex items-center space-x-2 text-xs text-gray-600 hover:text-orange-600 transition-colors duration-200 hover:bg-orange-50 px-3 py-2 rounded-lg"
                  >
                  
                  </button>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={copyToClipboard}
                    className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                    title="Copy message"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                  <button 
                    className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                    title="Share message"
                  >
                    <ExternalLink className="h-3 w-3" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Message;
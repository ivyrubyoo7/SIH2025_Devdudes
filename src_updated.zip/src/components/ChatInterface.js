import React, { useState } from 'react';
import ChatHeader from './ChatHeader';
import ChatMessages from './ChatMessages';
import ChatInput from './ChatInput';
import { useChat } from '../hooks/useChat';
import { ArrowLeft, Wheat } from 'lucide-react';

const ChatInterface = ({ onNavigateHome }) => {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [recordedAudio, setRecordedAudio] = useState(null);
  const [uploadedAudio, setUploadedAudio] = useState(null);
  
  const { 
    chatHistory, 
    isTyping, 
    sendMessage, 
    handleFeedback, 
    handleEscalate,
    processAudioTranscript 
  } = useChat();

  const handleSendMessage = () => {
    if (message.trim() || uploadedImage || uploadedFile || recordedAudio || uploadedAudio) {
      sendMessage(
        message, 
        uploadedImage || undefined, 
        uploadedFile || undefined,
        recordedAudio || undefined,
        uploadedAudio || undefined
      );
      setMessage('');
      setUploadedImage(null);
      setUploadedFile(null);
      setRecordedAudio(null);
      setUploadedAudio(null);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-gray-50 to-green-50/30 overflow-hidden">
      {/* Conditional Header - Show back button if onNavigateHome is provided */}
      {onNavigateHome ? (
        <header className="relative bg-gradient-to-r from-emerald-600 via-green-600 to-teal-600 shadow-xl">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-black/10">
            <div 
              className="absolute inset-0 opacity-30"
              style={{ 
                backgroundImage: `url("data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.05%22%3E%3Cpath d=%22M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` 
              }}
            ></div>
          </div>
          
          <div className="relative p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                {/* Back Button */}
                <button
                  onClick={onNavigateHome}
                  className="p-2 hover:bg-white/10 rounded-xl transition-all duration-200 group mr-2"
                  title="Back to Home"
                >
                  <ArrowLeft className="h-6 w-6 text-white group-hover:scale-110 transition-transform" />
                </button>
                
                {/* Logo */}
                <div className="relative">
                  <div className="w-16 h-16 bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/20 shadow-lg">
                    <Wheat className="h-8 w-8 text-white drop-shadow-sm" />
                  </div>
                </div>
                
                {/* Title */}
                <div className="text-white">
                  <h1 className="text-2xl font-bold tracking-tight">
                    FarmAssist AI
                  </h1>
                  <p className="text-emerald-100 text-sm font-medium">
                    Your intelligent farming companion
                  </p>
                </div>
              </div>

              {/* Status Indicator */}
              <div className="hidden md:flex items-center space-x-3">
                <div className="flex items-center space-x-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-white text-sm font-medium">AI Online</span>
                </div>
              </div>
            </div>
          </div>
        </header>
      ) : (
        // Use existing ChatHeader component when no navigation is needed
        <ChatHeader />
      )}
      
      {/* Chat Messages */}
      <ChatMessages 
        messages={chatHistory}
        onFeedback={handleFeedback}
        onEscalate={handleEscalate}
        isTyping={isTyping}
      />
      
      {/* Chat Input */}
      <ChatInput
        message={message}
        setMessage={setMessage}
        isRecording={isRecording}
        setIsRecording={setIsRecording}
        uploadedImage={uploadedImage}
        setUploadedImage={setUploadedImage}
        uploadedFile={uploadedFile}
        setUploadedFile={setUploadedFile}
        recordedAudio={recordedAudio}
        setRecordedAudio={setRecordedAudio}
        uploadedAudio={uploadedAudio}
        setUploadedAudio={setUploadedAudio}
        onSendMessage={handleSendMessage}
        processAudioTranscript={processAudioTranscript}
        isTyping={isTyping}
      />
    </div>
  );
};

export default ChatInterface;
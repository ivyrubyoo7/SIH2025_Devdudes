import React, { useRef, useState, useEffect } from 'react';
import { 
  Mic, 
  MicOff, 
  Send,
  X,
  Image,
  Paperclip,
  Upload,
  Headphones,
  AlertCircle,
  Play,
  Pause,
  Square
} from 'lucide-react';

// Backend API base URL
const API_BASE_URL = 'http://localhost:5000';

const ChatInput = ({ 
  message, 
  setMessage, 
  isRecording, 
  setIsRecording,
  uploadedImage,
  setUploadedImage,
  uploadedFile,
  setUploadedFile,
  recordedAudio,
  setRecordedAudio,
  uploadedAudio,
  setUploadedAudio,
  onSendMessage,
  processAudioTranscript,
  isTyping = false
}) => {
  const fileInputRef = useRef(null);
  const docInputRef = useRef(null);
  const audioInputRef = useRef(null);
  const textareaRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  
  const [isFocused, setIsFocused] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [pythonSpeechAvailable, setPythonSpeechAvailable] = useState(false);
  const [uploadedAudio, setUploadedAudio] = useState(null);
  const [recordedAudio, setRecordedAudio] = useState(null);
  const [backendStatus, setBackendStatus] = useState('checking');
  const [isPlaying, setIsPlaying] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [recordingTimer, setRecordingTimer] = useState(null);

  // Check backend health and speech service availability
  useEffect(() => {
    const checkBackendHealth = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/health`);
        if (response.ok) {
          const data = await response.json();
          setPythonSpeechAvailable(data.speech_available);
          setBackendStatus('connected');
          console.log('Backend connected:', data);
        }
      } catch (error) {
        console.log('Backend not available, using browser recording');
        setBackendStatus('offline');
        setPythonSpeechAvailable(false);
      }
    };
    
    checkBackendHealth();
  }, []);

  // Check if getUserMedia is supported
  useEffect(() => {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      setSpeechSupported(true);
    }
  }, []);

  // Start recording audio
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 44100
        } 
      });
      
      // Reset chunks
      audioChunksRef.current = [];
      
      // Create MediaRecorder
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus'
      });
      
      mediaRecorderRef.current = mediaRecorder;
      
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };
      
      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm;codecs=opus' });
        const audioUrl = URL.createObjectURL(audioBlob);
        
        // Create recorded audio object
        const recordedAudioData = {
          blob: audioBlob,
          url: audioUrl,
          duration: recordingTime,
          name: `Recording_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.webm`
        };
        
        setRecordedAudio(recordedAudioData);
        
        // Process with backend if available
        if (backendStatus === 'connected') {
          await processRecordedAudio(audioBlob);
        }
        
        // Stop all tracks
        stream.getTracks().forEach(track => track.stop());
      };
      
      // Start recording
      mediaRecorder.start(100); // Collect data every 100ms
      setIsRecording(true);
      setRecordingTime(0);
      
      // Start timer
      const timer = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
      setRecordingTimer(timer);
      
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  // Stop recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
      mediaRecorderRef.current.stop();
    }
    
    setIsRecording(false);
    
    if (recordingTimer) {
      clearInterval(recordingTimer);
      setRecordingTimer(null);
    }
  };

  // Process recorded audio with backend
  const processRecordedAudio = async (audioBlob) => {
    try {
      const formData = new FormData();
      formData.append('audio', audioBlob, 'recording.webm');
      
      const response = await fetch(`${API_BASE_URL}/process-audio`, {
        method: 'POST',
        body: formData
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.transcript) {
          setMessage(prev => prev + data.transcript);
          
          // Process with AI if entities are detected
          if (data.entities && data.entities.length > 0 && processAudioTranscript) {
            processAudioTranscript(data.transcript, data.entities);
          }
        }
      }
    } catch (error) {
      console.error('Failed to process recorded audio:', error);
    }
  };

  // Handle voice toggle
  const handleVoiceToggle = () => {
    if (!speechSupported) {
      alert('Audio recording is not supported in your browser.');
      return;
    }

    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  // Handle audio file upload for processing
  const handleAudioUpload = async (event) => {
    const file = event.target.files?.[0];
    if (file && backendStatus === 'connected') {
      const formData = new FormData();
      formData.append('audio', file);
      
      try {
        setUploadedAudio(file);
        const response = await fetch(`${API_BASE_URL}/process-audio`, {
          method: 'POST',
          body: formData
        });
        
        if (response.ok) {
          const data = await response.json();
          setMessage(prev => prev + data.transcript);
          
          // Process with AI if entities are detected
          if (data.entities && data.entities.length > 0 && processAudioTranscript) {
            processAudioTranscript(data.transcript, data.entities);
          }
        } else {
          throw new Error('Failed to process audio');
        }
      } catch (error) {
        console.error('Failed to process audio file:', error);
        alert('Failed to process audio file. Please try again.');
        setUploadedAudio(null);
      }
    } else if (file && backendStatus !== 'connected') {
      setUploadedAudio(file);
    }
  };

  // Play/pause recorded audio
  const toggleAudioPlayback = () => {
    if (!recordedAudio) return;
    
    const audio = document.getElementById('recorded-audio-player');
    if (!audio) return;
    
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play();
      setIsPlaying(true);
    }
  };

  const handleImageUpload = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setUploadedImage(e.target?.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileUpload = (event) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSendMessage();
    }
  };

  const adjustTextareaHeight = () => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    adjustTextareaHeight();
  }, [message]);

  return (
    <div className="bg-white border-t border-gray-200 shadow-2xl">
      <div className="max-w-6xl mx-auto px-6 py-6">
        
        {/* Backend Status Indicator */}
        {backendStatus === 'offline' && (
          <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
            <div className="flex items-center space-x-2 text-orange-700">
              <AlertCircle className="h-4 w-4" />
              <span className="text-sm font-medium">
                Backend offline - Audio transcription not available. Recording will be saved locally.
              </span>
            </div>
          </div>
        )}

        {/* Image Preview */}
        {uploadedImage && (
          <div className="mb-4">
            <div className="relative inline-block group">
              <div className="relative overflow-hidden rounded-xl border-2 border-emerald-200 shadow-lg">
                <img 
                  src={uploadedImage} 
                  alt="Preview" 
                  className="w-32 h-32 object-cover" 
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-200"></div>
              </div>
              <button 
                onClick={() => setUploadedImage(null)}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-110"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* File Preview */}
        {uploadedFile && (
          <div className="mb-4">
            <div className="relative inline-block group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl border-2 border-blue-200 shadow-lg bg-white">
                <Paperclip className="h-5 w-5 text-blue-500" />
                <span className="text-sm text-gray-700">{uploadedFile.name}</span>
              </div>
              <button 
                onClick={() => setUploadedFile(null)}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-110"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* Uploaded Audio File Preview */}
        {uploadedAudio && (
          <div className="mb-4">
            <div className="relative inline-block group">
              <div className="flex items-center space-x-3 px-4 py-2 rounded-xl border-2 border-purple-200 shadow-lg bg-white">
                <Headphones className="h-5 w-5 text-purple-500" />
                <span className="text-sm text-gray-700">{uploadedAudio.name}</span>
                {backendStatus === 'connected' && (
                  <span className="text-xs text-purple-600 font-medium">AI Processing Available</span>
                )}
              </div>
              <button 
                onClick={() => setUploadedAudio(null)}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-110"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {/* Recorded Audio Preview */}
        {recordedAudio && (
          <div className="mb-4">
            <div className="relative inline-block group">
              <div className="flex items-center space-x-3 px-4 py-3 rounded-xl border-2 border-green-200 shadow-lg bg-white">
                <div className="w-10 h-10 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                  <Mic className="h-5 w-5 text-white" />
                </div>
                
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium text-gray-700">Recorded Audio</span>
                    <span className="text-xs text-gray-500">({formatTime(recordedAudio.duration)})</span>
                    {backendStatus === 'connected' && (
                      <span className="text-xs text-green-600 font-medium">Transcribed</span>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2 mt-1">
                    <button
                      onClick={toggleAudioPlayback}
                      className="p-1 text-green-600 hover:text-green-700 transition-colors"
                    >
                      {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    </button>
                    <div className="text-xs text-gray-500">{recordedAudio.name}</div>
                  </div>
                </div>
              </div>
              
              <button 
                onClick={() => {
                  setRecordedAudio(null);
                  setIsPlaying(false);
                }}
                className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl hover:scale-110"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            
            {/* Hidden audio element for playback */}
            <audio
              id="recorded-audio-player"
              src={recordedAudio.url}
              onEnded={() => setIsPlaying(false)}
              onPause={() => setIsPlaying(false)}
              onPlay={() => setIsPlaying(true)}
            />
          </div>
        )}
        
        {/* Input Container */}
        <div className={`relative bg-gray-50 rounded-2xl border-2 transition-all duration-300 ${
          isFocused 
            ? 'border-emerald-500 shadow-lg shadow-emerald-500/10 bg-white' 
            : 'border-gray-200 hover:border-gray-300'
        }`}>
          
          {/* Main Input Area */}
          <div className="flex items-center p-4 space-x-3">
            {/* Image Attachment */}
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-3 text-gray-500 hover:text-emerald-600 hover:bg-emerald-100 rounded-xl transition-all duration-200 group flex-shrink-0"
              title="Upload crop image"
            >
              <Image className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />

            {/* File Attachment */}
            <button
              onClick={() => docInputRef.current?.click()}
              className="p-3 text-gray-500 hover:text-blue-600 hover:bg-blue-100 rounded-xl transition-all duration-200 group flex-shrink-0"
              title="Upload document"
            >
              <Paperclip className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </button>
            <input
              ref={docInputRef}
              type="file"
              accept=".pdf,.doc,.docx,.txt,.csv"
              onChange={handleFileUpload}
              className="hidden"
            />

            {/* Audio File Upload */}
            <button
              onClick={() => audioInputRef.current?.click()}
              className="p-3 text-gray-500 hover:text-purple-600 hover:bg-purple-100 rounded-xl transition-all duration-200 group flex-shrink-0"
              title="Upload audio file"
            >
              <Upload className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </button>
            <input
              ref={audioInputRef}
              type="file"
              accept=".wav,.mp3,.m4a,.ogg,.webm"
              onChange={handleAudioUpload}
              className="hidden"
            />
            
            {/* Text Input */}
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                placeholder={isRecording ? "Recording audio... Click mic to stop" : "Ask about your crops, diseases, or farming practices..."}
                className="w-full bg-transparent border-none outline-none resize-none text-gray-800 placeholder-gray-400 text-sm leading-relaxed py-3"
                rows={1}
                style={{ minHeight: '48px', maxHeight: '120px' }}
                disabled={isTyping}
              />
            </div>
            
            {/* Voice Recording Button */}
            <button
              onClick={handleVoiceToggle}
              disabled={!speechSupported}
              className={`p-3 rounded-xl transition-all duration-200 flex-shrink-0 relative ${
                isRecording 
                  ? 'bg-red-500 text-white shadow-lg shadow-red-500/25 animate-pulse' 
                  : speechSupported
                  ? 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-100'
                  : 'text-gray-300 cursor-not-allowed'
              }`}
              title={
                !speechSupported 
                  ? 'Voice recording not supported' 
                  : isRecording 
                  ? 'Stop recording' 
                  : 'Start voice recording'
              }
            >
              {isRecording ? <Square className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>
            
            {/* Send Button */}
            <button
              onClick={onSendMessage}
              disabled={(!message.trim() && !uploadedImage && !uploadedFile && !uploadedAudio && !recordedAudio) || isTyping}
              className={`p-3 rounded-xl transition-all duration-200 transform flex-shrink-0 ${
                (message.trim() || uploadedImage || uploadedFile || uploadedAudio || recordedAudio) && !isTyping
                  ? 'bg-gradient-to-r from-emerald-500 to-green-600 text-white shadow-lg shadow-emerald-500/25 hover:shadow-xl hover:scale-105' 
                  : 'bg-gray-200 text-gray-400 cursor-not-allowed'
              }`}
              title="Send message"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
          
          {/* Recording Indicator */}
          {isRecording && (
            <div className="px-4 pb-4">
              <div className="flex items-center justify-center">
                <div className="flex items-center space-x-4 px-6 py-3 rounded-full bg-gradient-to-r from-red-500 to-pink-500 text-white shadow-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                  <span className="text-sm font-semibold">Recording Audio</span>
                  <div className="text-sm font-mono bg-white/20 px-2 py-1 rounded">
                    {formatTime(recordingTime)}
                  </div>
                  <span className="text-xs opacity-75">Click ⏹️ to stop</span>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Quick Actions & Status */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center space-x-4">
            <button className="text-xs text-gray-500 hover:text-emerald-600 transition-colors duration-200 font-medium">
              Quick tips
            </button>
            <button className="text-xs text-gray-500 hover:text-emerald-600 transition-colors duration-200 font-medium">
              Crop diseases
            </button>
            <button className="text-xs text-gray-500 hover:text-emerald-600 transition-colors duration-200 font-medium">
              Weather alerts
            </button>
            {backendStatus === 'connected' && pythonSpeechAvailable && (
              <span className="text-xs text-emerald-600 font-medium flex items-center space-x-1">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                <span>AI Speech Enhanced</span>
              </span>
            )}
            {backendStatus === 'connected' && (
              <span className="text-xs text-green-600 font-medium flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Backend Connected</span>
              </span>
            )}
          </div>
          
          {/* Disclaimer */}
          <div className="text-xs text-gray-400">
            FarmAssist AI provides guidance based on agricultural best practices
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;
import React from 'react';
import { 
  Wheat, 
  Leaf, 
  CloudRain, 
  Bug, 
  Thermometer, 
  BarChart3,
  MessageCircle,
  Camera,
  ArrowRight,
  Sparkles
} from 'lucide-react';

const HomePage = ({ onNavigateToChat }) => {
  // Removed unused isHovering state since it wasn't being used

  const features = [
    {
      icon: <Camera className="h-8 w-8" />,
      title: "Crop Disease Detection",
      description: "Upload photos to instantly identify plant diseases and get treatment recommendations",
      color: "from-emerald-500 to-green-600"
    },
    {
      icon: <Leaf className="h-8 w-8" />,
      title: "Soil Health Analysis", 
      description: "Comprehensive soil testing guidance and nutrient management advice",
      color: "from-amber-500 to-orange-600"
    },
    {
      icon: <CloudRain className="h-8 w-8" />,
      title: "Weather Intelligence",
      description: "Real-time weather alerts and irrigation scheduling recommendations",
      color: "from-blue-500 to-cyan-600"
    },
    {
      icon: <Bug className="h-8 w-8" />,
      title: "Pest Management",
      description: "Identify pests early and get eco-friendly treatment solutions",
      color: "from-red-500 to-pink-600"
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "Yield Optimization",
      description: "Data-driven insights to maximize crop productivity and profits",
      color: "from-purple-500 to-indigo-600"
    },
    {
      icon: <Thermometer className="h-8 w-8" />,
      title: "Climate Advisory",
      description: "Seasonal planning and climate adaptation strategies for your region",
      color: "from-teal-500 to-emerald-600"
    }
  ];

  const stats = [
    { number: "50,000+", label: "Farmers Helped" },
    { number: "95%", label: "Accuracy Rate" },
    { number: "24/7", label: "Support Available" },
    { number: "100+", label: "Crop Types Supported" }
  ];

  const testimonials = [
    {
      name: "Rajesh Kumar",
      location: "Punjab, India",
      text: "FarmAssist helped me identify wheat rust early, saving my entire crop. The AI recommendations increased my yield by 30%.",
      avatar: "👨‍🌾"
    },
    {
      name: "Priya Sharma", 
      location: "Maharashtra, India",
      text: "The soil analysis feature transformed my tomato farming. I now get precise fertilizer recommendations that save money.",
      avatar: "👩‍🌾"
    },
    {
      name: "Mohammed Ali",
      location: "Karnataka, India", 
      text: "Voice input in my local language makes it so easy to ask questions while working in the field. Excellent tool!",
      avatar: "👨‍🌾"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b border-green-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl flex items-center justify-center">
                <Wheat className="h-7 w-7 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-green-700 bg-clip-text text-transparent">
                FarmAssist AI
              </h1>
            </div>
            
            <div className="flex items-center space-x-6">
              <a href="#features" className="text-gray-600 hover:text-emerald-600 transition-colors">Features</a>
              <a href="#about" className="text-gray-600 hover:text-emerald-600 transition-colors">About</a>
              <a href="#contact" className="text-gray-600 hover:text-emerald-600 transition-colors">Contact</a>
              <button 
                onClick={onNavigateToChat}
                className="bg-gradient-to-r from-emerald-500 to-green-600 text-white px-6 py-3 rounded-xl font-semibold hover:shadow-lg hover:scale-105 transition-all duration-200"
              >
                Start Farming Chat
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-20 pb-32 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-green-400/10 to-emerald-400/10"></div>
        <div className="max-w-7xl mx-auto px-6 relative">
          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-sm font-semibold mb-8">
              <Sparkles className="h-4 w-4" />
              <span>AI-Powered Agricultural Intelligence</span>
            </div>
            
            <h2 className="text-5xl md:text-7xl font-bold text-gray-900 mb-8 leading-tight">
              Smart Farming
              <span className="block bg-gradient-to-r from-emerald-500 to-green-600 bg-clip-text text-transparent">
                Starts Here
              </span>
            </h2>
            
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12 leading-relaxed">
              Revolutionize your agricultural practices with AI-powered crop monitoring, disease detection, 
              and personalized farming recommendations. Get expert advice in your pocket, 24/7.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <button 
                onClick={onNavigateToChat}
                className="bg-gradient-to-r from-emerald-500 to-green-600 text-white px-8 py-4 rounded-2xl font-bold text-lg hover:shadow-2xl hover:shadow-emerald-500/25 hover:scale-105 transition-all duration-300 flex items-center space-x-3"
              >
                <MessageCircle className="h-6 w-6" />
                <span>Start AI Chat</span>
                <ArrowRight className="h-5 w-5" />
              </button>
              
              <button 
                onClick={onNavigateToChat}
                className="border-2 border-emerald-200 text-emerald-700 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-emerald-50 hover:scale-105 transition-all duration-300 flex items-center space-x-3"
              >
                <Camera className="h-6 w-6" />
                <span>Upload Crop Photo</span>
              </button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-emerald-600 mb-2">{stat.number}</div>
                  <div className="text-gray-600 font-medium">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-white/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">
              Comprehensive Farming Solutions
            </h3>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From seed to harvest, our AI-powered platform provides intelligent insights 
              for every stage of your farming journey.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 border border-gray-100"
              >
                <div className={`w-16 h-16 bg-gradient-to-r ${feature.color} rounded-2xl flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  {feature.icon}
                </div>
                
                <h4 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h4>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                
                <div className="mt-6 flex items-center text-emerald-600 font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span>Learn more</span>
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 bg-gradient-to-r from-emerald-50 to-green-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">How It Works</h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Get started with FarmAssist AI in three simple steps
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">
                1
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Ask or Upload</h4>
              <p className="text-gray-600">
                Type your farming question, speak using voice input, or upload photos of your crops for analysis.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">
                2
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">AI Analysis</h4>
              <p className="text-gray-600">
                Our advanced AI processes your input and analyzes against our comprehensive agricultural database.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-r from-emerald-500 to-green-600 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">
                3
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-4">Get Solutions</h4>
              <p className="text-gray-600">
                Receive personalized recommendations, treatment plans, and expert advice tailored to your needs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">Trusted by Farmers</h3>
            <p className="text-xl text-gray-600">
              See how FarmAssist AI is transforming agriculture across India
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 rounded-2xl p-8 relative">
                <div className="text-6xl mb-4">{testimonial.avatar}</div>
                <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.text}"</p>
                <div>
                  <div className="font-bold text-gray-900">{testimonial.name}</div>
                  <div className="text-gray-600 text-sm">{testimonial.location}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-emerald-600 to-green-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="max-w-4xl mx-auto px-6 text-center relative">
          <h3 className="text-4xl font-bold mb-6">Ready to Transform Your Farming?</h3>
          <p className="text-xl mb-8 text-emerald-100">
            Join thousands of farmers who are already using AI to increase yields and reduce costs.
          </p>
          <button 
            onClick={onNavigateToChat}
            className="bg-white text-emerald-600 px-8 py-4 rounded-2xl font-bold text-lg hover:shadow-2xl hover:scale-105 transition-all duration-300 flex items-center space-x-3 mx-auto"
          >
            <MessageCircle className="h-6 w-6" />
            <span>Start Your AI Farming Journey</span>
            <ArrowRight className="h-5 w-5" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-gradient-to-r from-emerald-500 to-green-600 rounded-lg flex items-center justify-center">
                  <Wheat className="h-6 w-6 text-white" />
                </div>
                <h4 className="text-xl font-bold">FarmAssist AI</h4>
              </div>
              <p className="text-gray-400">
                Empowering farmers with intelligent agricultural solutions for a sustainable future.
              </p>
            </div>
            
            <div>
              <h5 className="font-semibold mb-4">Features</h5>
              <ul className="space-y-2 text-gray-400">
                <li>Crop Disease Detection</li>
                <li>Soil Health Analysis</li>
                <li>Weather Intelligence</li>
                <li>Pest Management</li>
              </ul>
            </div>
            
            <div>
              <h5 className="font-semibold mb-4">Support</h5>
              <ul className="space-y-2 text-gray-400">
                <li>Help Center</li>
                <li>Expert Connect</li>
                <li>Community Forum</li>
                <li>Training Resources</li>
              </ul>
            </div>
            
            <div>
              <h5 className="font-semibold mb-4">Contact</h5>
              <ul className="space-y-2 text-gray-400">
                <li>support@farmassist.ai</li>
                <li>+91 1800-FARM-AI</li>
                <li>Available 24/7</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 FarmAssist AI. All rights reserved. Built for farmers, by technology.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default HomePage;
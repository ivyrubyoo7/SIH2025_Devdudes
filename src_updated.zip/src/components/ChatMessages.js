import React, { useEffect, useRef } from 'react';
import Message from './Message';


const ChatMessages = ({ 
  messages, 
  onFeedback, 
  onEscalate,
  isTyping = false
}) => {
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  // Background pattern as inline style to avoid Tailwind issues
  const backgroundPatternStyle = {
    backgroundImage: `url("data:image/svg+xml,%3Csvg width='100' height='100' viewBox='0 0 100 100' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill-opacity='0.03'%3E%3Cpath d='M50 50c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10zm20 0c0-5.5-4.5-10-10-10s-10 4.5-10 10 4.5 10 10 10 10-4.5 10-10z' fill='%2322c55e'/%3E%3C/g%3E%3C/svg%3E")`,
    opacity: 0.4
  };

  return (
    <div className="flex-1 overflow-y-auto">
      {/* Background Pattern */}
      <div className="min-h-full bg-gradient-to-br from-gray-50 via-green-50/30 to-emerald-50/50 relative">
        <div 
          className="absolute inset-0"
          style={backgroundPatternStyle}
        ></div>
        
        <div className="relative max-w-6xl mx-auto px-6 py-8">
          {messages.map((message, index) => (
            <div 
              key={message.id} 
              className="opacity-0 animate-fade-in"
              style={{ 
                animationDelay: `${index * 100}ms`,
                animationFillMode: 'forwards'
              }}
            >
              <Message 
                message={message} 
                onFeedback={onFeedback}
                onEscalate={onEscalate}
              />
            </div>
          ))}
          
          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex justify-start mb-8 animate-fade-in">
              <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-lg max-w-md">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-green-600 rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-white rounded-full animate-pulse"></div>
                  </div>
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div 
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" 
                      style={{ animationDelay: '0.1s' }}
                    ></div>
                    <div 
                      className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" 
                      style={{ animationDelay: '0.2s' }}
                    ></div>
                  </div>
                  <span className="text-sm text-gray-500 font-medium">AI is thinking...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>
      
      {/* Add custom CSS for fade-in animation */}
      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in {
          animation: fade-in 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default ChatMessages;